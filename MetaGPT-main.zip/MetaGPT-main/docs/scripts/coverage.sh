coverage run --source ./metagpt -m pytest && coverage report -m && coverage html && open htmlcov/index.html
